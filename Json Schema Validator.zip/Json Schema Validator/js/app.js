/**
 * JSON Schema Generator
 * A tool to generate JSON schemas
 */

document.addEventListener('DOMContentLoaded', () => {
    // Initialize the application
    initApp();
});

// Global variables
let currentTheme = 'light';

/**
 * Initialize the application
 */
function initApp() {
    // Initialize theme toggling
    initThemeToggle();
    
    // Initialize Schema generation functionality
    initSchemaGeneration();
    
    // Debug information
    debugLibraries();
}

/**
 * Initialize theme toggle
 */
function initThemeToggle() {
    const themeToggleBtn = document.getElementById('theme-toggle-btn');
    const themeIcon = themeToggleBtn.querySelector('i');
    
    // Check for saved theme preference
    const savedTheme = localStorage.getItem('theme');
    if (savedTheme) {
        setTheme(savedTheme);
    }
    
    themeToggleBtn.addEventListener('click', () => {
        // Toggle theme
        const newTheme = currentTheme === 'light' ? 'dark' : 'light';
        setTheme(newTheme);
        
        // Save theme preference
        localStorage.setItem('theme', newTheme);
    });
    
    function setTheme(theme) {
        currentTheme = theme;
        
        if (theme === 'dark') {
            document.documentElement.setAttribute('data-theme', 'dark');
            themeIcon.className = 'fas fa-sun';
        } else {
            document.documentElement.removeAttribute('data-theme');
            themeIcon.className = 'fas fa-moon';
        }
    }
}

/**
 * Initialize Schema generation functionality
 */
function initSchemaGeneration() {
    const jsonInput = document.getElementById('json-input-gen');
    const schemaOutput = document.getElementById('schema-output');
    const generateBtn = document.getElementById('generate-btn');
    const copyBtn = document.getElementById('copy-schema');
    const formatBtn = document.getElementById('format-json-gen');
    const sampleBtn = document.getElementById('sample-json-gen');
    const clearBtn = document.getElementById('clear-json-gen');
    
    // Generate schema
    generateBtn.addEventListener('click', () => {
        const json = jsonInput.value.trim();
        
        if (!json) {
            showToast('Please enter JSON data', 'error');
            return;
        }
        
        try {
            // Parse the JSON
            const parsed = JSON.parse(json);
            
            // Generate schema
            let schema;
            
            // Use jsonschema-generator library if available, otherwise use custom function
            if (typeof JSONSchemaGenerator !== 'undefined') {
                schema = JSONSchemaGenerator.fromExample(parsed);
            } else {
                schema = generateSchemaFromJson(parsed);
            }
            
            // Format and display schema
            const formattedSchema = JSON.stringify(schema, null, 2);
            schemaOutput.textContent = formattedSchema;
            
            // Apply syntax highlighting
            applySyntaxHighlighting(schemaOutput);
            
            // Show toast notification
            showToast('Schema generated successfully', 'success');
        } catch (e) {
            // Show error message
            schemaOutput.textContent = `Error generating schema: ${e.message}`;
            showToast('Error generating schema', 'error');
        }
    });
    
    // Copy schema to clipboard
    copyBtn.addEventListener('click', () => {
        const schema = schemaOutput.textContent;
        
        if (!schema) {
            showToast('No schema to copy', 'error');
            return;
        }
        
        // Copy to clipboard
        navigator.clipboard.writeText(schema)
            .then(() => {
                showToast('Schema copied to clipboard', 'success');
            })
            .catch(err => {
                showToast('Failed to copy schema', 'error');
                console.error('Could not copy text: ', err);
            });
    });
    
    // Format JSON
    formatBtn.addEventListener('click', () => {
        const json = jsonInput.value.trim();
        
        if (!json) {
            showToast('Please enter JSON data', 'error');
            return;
        }
        
        try {
            // Parse and stringify for pretty formatting
            const parsed = JSON.parse(json);
            const formatted = JSON.stringify(parsed, null, 2);
            
            // Update input with formatted JSON
            jsonInput.value = formatted;
            
            // Show toast notification
            showToast('JSON formatted', 'success');
        } catch (e) {
            // Show error message
            showToast(`Error formatting JSON: ${e.message}`, 'error');
        }
    });
    
    // Insert sample JSON
    sampleBtn.addEventListener('click', () => {
        jsonInput.value = getSampleJson();
        showToast('Sample JSON inserted', 'info');
    });
    
    // Clear JSON
    clearBtn.addEventListener('click', () => {
        jsonInput.value = '';
        schemaOutput.textContent = '';
        showToast('JSON cleared', 'info');
    });
}

/**
 * Generate a sample JSON object
 * @returns {string} - Sample JSON string
 */
function getSampleJson() {
    const sampleObject = {
        "id": 1,
        "name": "John Doe",
        "email": "john.doe@example.com",
        "active": true,
        "age": 30,
        "scores": [85, 90, 78],
        "address": {
            "street": "123 Main St",
            "city": "Anytown",
            "zipCode": "12345"
        },
        "tags": ["developer", "javascript", "web"],
        "rating": 4.5,
        "metadata": {
            "lastLogin": "2023-06-15T14:30:00Z",
            "preferences": {
                "theme": "dark",
                "notifications": true
            }
        }
    };
    
    return JSON.stringify(sampleObject, null, 2);
}

/**
 * Apply syntax highlighting to a pre element containing JSON
 * @param {HTMLElement} element - The element containing JSON
 */
function applySyntaxHighlighting(element) {
    let html = element.textContent;
    
    // Replace JSON syntax with spans, but don't style the keys
    html = html.replace(/"([^"]+)"/g, '<span class="string">"$1"</span>');
    html = html.replace(/\b(true|false)\b/g, '<span class="boolean">$1</span>');
    html = html.replace(/\b(null)\b/g, '<span class="null">$1</span>');
    html = html.replace(/\b(\d+)\b/g, '<span class="number">$1</span>');
    
    element.innerHTML = html;
}

/**
 * Generate a JSON schema from a JSON object
 * @param {Object} json - The JSON object
 * @returns {Object} - The generated schema
 */
function generateSchemaFromJson(json) {
    // Create a base schema
    const schema = {
        "$schema": "http://json-schema.org/draft-04/schema#",
        "type": "object",
        "properties": {},
        "required": []
    };
    
    if (Array.isArray(json)) {
        schema.type = "array";
        if (json.length > 0) {
            schema.items = [];
            // Process each item in the array
            json.forEach(item => {
                schema.items.push(inferType(item));
            });
        }
    } else if (typeof json === 'object' && json !== null) {
        // Process each property of the object
        for (const key in json) {
            if (json.hasOwnProperty(key)) {
                schema.properties[key] = inferType(json[key]);
                schema.required.push(key);
            }
        }
    } else {
        // For primitive values
        return inferType(json);
    }
    
    return schema;
    
    /**
     * Infer type information for a value
     * @param {*} value - The value to infer type for
     * @returns {Object} - Type information
     */
    function inferType(value) {
        if (value === null) {
            return { "type": "null" };
        }
        
        if (Array.isArray(value)) {
            const result = {
                "type": "array"
            };
            
            if (value.length > 0) {
                result.items = [];
                // Process each item in the array individually
                value.forEach(item => {
                    result.items.push(inferType(item));
                });
            }
            
            return result;
        }
        
        if (typeof value === 'object') {
            const nestedSchema = {
                "type": "object",
                "properties": {},
                "required": []
            };
            
            for (const key in value) {
                if (value.hasOwnProperty(key)) {
                    nestedSchema.properties[key] = inferType(value[key]);
                    nestedSchema.required.push(key);
                }
            }
            
            return nestedSchema;
        }
        
        // Handle primitive types more specifically
        if (typeof value === 'number') {
            if (Number.isInteger(value)) {
                return { "type": "integer" };
            } else {
                return { "type": "number" };
            }
        }
        
        return { "type": typeof value };
    }
}

/**
 * Show a toast notification
 * @param {string} message - The message to show
 * @param {string} type - The type of notification (success, error, info)
 */
function showToast(message, type = 'info') {
    const toastContainer = document.getElementById('toast-container');
    
    // Create toast element
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    
    // Add appropriate icon
    let icon;
    switch (type) {
        case 'success':
            icon = 'fas fa-check-circle';
            break;
        case 'error':
            icon = 'fas fa-exclamation-circle';
            break;
        default:
            icon = 'fas fa-info-circle';
    }
    
    toast.innerHTML = `<i class="${icon}"></i> ${message}`;
    
    // Add to container
    toastContainer.appendChild(toast);
    
    // Remove after animation
    setTimeout(() => {
        toast.style.animation = 'slideOut 0.3s forwards';
        
        toast.addEventListener('animationend', () => {
            toast.remove();
        });
    }, 3000);
}

/**
 * Debug information about libraries
 */
function debugLibraries() {
    console.log('-- Library Debug Information --');
    console.log('JsonLint:', typeof jsonlint !== 'undefined' ? 'Available' : 'Not available');
    console.log('JSONSchemaGenerator:', typeof JSONSchemaGenerator !== 'undefined' ? 'Available' : 'Not available');
    console.log('-----------------------------');
} 
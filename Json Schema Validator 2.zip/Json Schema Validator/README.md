# JSON Schema Validator

A Java desktop application that allows you to validate JSON data and generate JSON schemas.

## Features

- **JSON Validation**: Validate the syntax of your JSON data
- **JSON Schema Generation**: Automatically generate a JSON schema from your JSON data
- **Schema Validation**: Validate your JSON data against a JSON schema

## Getting Started

### Prerequisites

- Java JDK 11 or higher
- Maven 3.6 or higher

### Installation

1. Clone the repository:
   ```
   git clone https://github.com/yourusername/json-schema-validator.git
   cd json-schema-validator
   ```

2. Build the application with Maven:
   ```
   mvn clean package
   ```

3. Run the application:
   ```
   java -jar target/json-schema-validator-1.0-SNAPSHOT-jar-with-dependencies.jar
   ```

## Usage

### JSON Validation

1. Go to the "JSON Validation" tab
2. Enter your JSON data in the input area (or use the "Insert Sample JSON" button)
3. Click the "Validate JSON" button
4. The validation result will appear in the output area
5. You can also format your JSON using the "Format JSON" button

### Schema Generation

1. Go to the "Schema Generation" tab
2. Enter your JSON data in the input area
3. Click the "Generate Schema" button
4. The generated schema will appear in the output area
5. You can copy the schema to clipboard using the "Copy Schema" button

### Schema Validation

1. Go to the "Schema Validation" tab
2. Enter your JSON data in the left input area
3. Enter your JSON schema in the right input area
4. Click the "Validate Against Schema" button
5. The validation result will appear in the output area

## Technical Details

The application uses the following libraries:

- **Jackson**: For JSON processing
- **Everit JSON Schema**: For JSON schema validation
- **VicTools jsonschema-generator**: For JSON schema generation
- **Java Swing**: For the user interface

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details. 
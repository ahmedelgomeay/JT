package com.jsonvalidator;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.datatransfer.StringSelection;
import java.awt.datatransfer.Clipboard;

/**
 * Main UI class for the JSON Schema Validator application.
 */
public class JsonSchemaValidatorUI extends JFrame {
    private JTextArea jsonInputArea;
    private JTextArea outputArea;
    private JTabbedPane tabbedPane;
    private JTextArea schemaInputArea;
    private JTextArea schemaOutputArea;
    private JLabel statusLabel;

    /**
     * Constructs the main application UI.
     */
    public JsonSchemaValidatorUI() {
        // Configure basic frame properties
        setTitle("JSON Schema Validator");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1000, 700);
        setLocationRelativeTo(null);
        
        // Set layout for the content pane
        JPanel contentPane = new JPanel(new BorderLayout(10, 10));
        contentPane.setBorder(new EmptyBorder(10, 10, 10, 10));
        setContentPane(contentPane);
        
        // Create status bar
        statusLabel = new JLabel("Ready");
        statusLabel.setBorder(new EmptyBorder(5, 5, 5, 5));
        contentPane.add(statusLabel, BorderLayout.SOUTH);
        
        // Create tabbed pane for different functionalities
        tabbedPane = new JTabbedPane();
        contentPane.add(tabbedPane, BorderLayout.CENTER);
        
        // Add tabs
        tabbedPane.addTab("JSON Validation", createValidationPanel());
        tabbedPane.addTab("Schema Generation", createSchemaGenerationPanel());
        tabbedPane.addTab("Schema Validation", createSchemaValidationPanel());
        
        // Create menu bar
        createMenuBar();
    }
    
    /**
     * Creates the menu bar for the application
     */
    private void createMenuBar() {
        JMenuBar menuBar = new JMenuBar();
        
        // File menu
        JMenu fileMenu = new JMenu("File");
        
        JMenuItem exitItem = new JMenuItem("Exit");
        exitItem.addActionListener(e -> System.exit(0));
        
        fileMenu.add(exitItem);
        menuBar.add(fileMenu);
        
        // Help menu
        JMenu helpMenu = new JMenu("Help");
        
        JMenuItem aboutItem = new JMenuItem("About");
        aboutItem.addActionListener(e -> showAboutDialog());
        
        helpMenu.add(aboutItem);
        menuBar.add(helpMenu);
        
        setJMenuBar(menuBar);
    }
    
    /**
     * Shows the about dialog
     */
    private void showAboutDialog() {
        JOptionPane.showMessageDialog(this,
                "JSON Schema Validator\n" +
                "Version 1.0\n\n" +
                "A tool to validate JSON data and generate JSON schema.",
                "About JSON Schema Validator",
                JOptionPane.INFORMATION_MESSAGE);
    }
    
    /**
     * Creates the panel for JSON validation functionality
     */
    private JPanel createValidationPanel() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBorder(new EmptyBorder(10, 10, 10, 10));
        
        // Input area
        JPanel inputPanel = new JPanel(new BorderLayout());
        inputPanel.setBorder(BorderFactory.createTitledBorder("JSON Input"));
        
        jsonInputArea = new JTextArea();
        jsonInputArea.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 14));
        JScrollPane inputScrollPane = new JScrollPane(jsonInputArea);
        inputPanel.add(inputScrollPane, BorderLayout.CENTER);
        
        // Sample data button
        JButton sampleDataButton = new JButton("Insert Sample JSON");
        sampleDataButton.addActionListener(e -> insertSampleJson());
        inputPanel.add(sampleDataButton, BorderLayout.SOUTH);
        
        // Output area
        JPanel outputPanel = new JPanel(new BorderLayout());
        outputPanel.setBorder(BorderFactory.createTitledBorder("Validation Result"));
        
        outputArea = new JTextArea();
        outputArea.setEditable(false);
        outputArea.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 14));
        JScrollPane outputScrollPane = new JScrollPane(outputArea);
        outputPanel.add(outputScrollPane, BorderLayout.CENTER);
        
        // Buttons panel
        JPanel buttonsPanel = new JPanel();
        
        JButton validateButton = new JButton("Validate JSON");
        validateButton.addActionListener(this::validateJson);
        
        JButton formatButton = new JButton("Format JSON");
        formatButton.addActionListener(this::formatJson);
        
        JButton clearButton = new JButton("Clear");
        clearButton.addActionListener(e -> {
            jsonInputArea.setText("");
            outputArea.setText("");
            statusLabel.setText("Cleared");
        });
        
        buttonsPanel.add(validateButton);
        buttonsPanel.add(formatButton);
        buttonsPanel.add(clearButton);
        
        // Arrange components in the panel
        JSplitPane splitPane = new JSplitPane(JSplitPane.VERTICAL_SPLIT, inputPanel, outputPanel);
        splitPane.setDividerLocation(300);
        splitPane.setResizeWeight(0.5);
        
        panel.add(splitPane, BorderLayout.CENTER);
        panel.add(buttonsPanel, BorderLayout.SOUTH);
        
        return panel;
    }
    
    /**
     * Creates the panel for schema generation functionality
     */
    private JPanel createSchemaGenerationPanel() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBorder(new EmptyBorder(10, 10, 10, 10));
        
        // Input area
        JPanel inputPanel = new JPanel(new BorderLayout());
        inputPanel.setBorder(BorderFactory.createTitledBorder("JSON Input"));
        
        JTextArea jsonSchemaInputArea = new JTextArea();
        jsonSchemaInputArea.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 14));
        JScrollPane inputScrollPane = new JScrollPane(jsonSchemaInputArea);
        inputPanel.add(inputScrollPane, BorderLayout.CENTER);
        
        // Output area
        JPanel outputPanel = new JPanel(new BorderLayout());
        outputPanel.setBorder(BorderFactory.createTitledBorder("Generated Schema"));
        
        schemaOutputArea = new JTextArea();
        schemaOutputArea.setEditable(false);
        schemaOutputArea.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 14));
        JScrollPane outputScrollPane = new JScrollPane(schemaOutputArea);
        outputPanel.add(outputScrollPane, BorderLayout.CENTER);
        
        // Buttons panel
        JPanel buttonsPanel = new JPanel();
        
        JButton generateButton = new JButton("Generate Schema");
        generateButton.addActionListener(e -> {
            try {
                String jsonInput = jsonSchemaInputArea.getText().trim();
                if (jsonInput.isEmpty()) {
                    JOptionPane.showMessageDialog(this, "Please enter JSON data.", "Empty Input", JOptionPane.WARNING_MESSAGE);
                    return;
                }
                
                JsonProcessor.ValidationResult validationResult = JsonProcessor.validateJson(jsonInput);
                if (!validationResult.isValid()) {
                    JOptionPane.showMessageDialog(this, "Invalid JSON input: " + validationResult.getMessage(), "Validation Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                
                String schema = JsonProcessor.generateJsonSchema(jsonInput);
                schemaOutputArea.setText(schema);
                statusLabel.setText("Schema generated successfully");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Error generating schema: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
                statusLabel.setText("Error generating schema");
            }
        });
        
        JButton copyButton = new JButton("Copy Schema");
        copyButton.addActionListener(e -> {
            String schema = schemaOutputArea.getText();
            if (!schema.isEmpty()) {
                StringSelection selection = new StringSelection(schema);
                Clipboard clipboard = Toolkit.getDefaultToolkit().getSystemClipboard();
                clipboard.setContents(selection, null);
                statusLabel.setText("Schema copied to clipboard");
            }
        });
        
        JButton clearButton = new JButton("Clear");
        clearButton.addActionListener(e -> {
            jsonSchemaInputArea.setText("");
            schemaOutputArea.setText("");
            statusLabel.setText("Cleared");
        });
        
        buttonsPanel.add(generateButton);
        buttonsPanel.add(copyButton);
        buttonsPanel.add(clearButton);
        
        // Arrange components in the panel
        JSplitPane splitPane = new JSplitPane(JSplitPane.VERTICAL_SPLIT, inputPanel, outputPanel);
        splitPane.setDividerLocation(300);
        splitPane.setResizeWeight(0.5);
        
        panel.add(splitPane, BorderLayout.CENTER);
        panel.add(buttonsPanel, BorderLayout.SOUTH);
        
        return panel;
    }
    
    /**
     * Creates the panel for schema validation functionality
     */
    private JPanel createSchemaValidationPanel() {
        JPanel panel = new JPanel(new BorderLayout(10, 10));
        panel.setBorder(new EmptyBorder(10, 10, 10, 10));
        
        // Create a split pane for top section (JSON and Schema)
        JSplitPane topSplitPane = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT);
        
        // JSON input panel
        JPanel jsonPanel = new JPanel(new BorderLayout());
        jsonPanel.setBorder(BorderFactory.createTitledBorder("JSON Input"));
        
        JTextArea schemaValidationJsonArea = new JTextArea();
        schemaValidationJsonArea.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 14));
        JScrollPane jsonScrollPane = new JScrollPane(schemaValidationJsonArea);
        jsonPanel.add(jsonScrollPane, BorderLayout.CENTER);
        
        // Schema input panel
        JPanel schemaPanel = new JPanel(new BorderLayout());
        schemaPanel.setBorder(BorderFactory.createTitledBorder("JSON Schema"));
        
        schemaInputArea = new JTextArea();
        schemaInputArea.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 14));
        JScrollPane schemaScrollPane = new JScrollPane(schemaInputArea);
        schemaPanel.add(schemaScrollPane, BorderLayout.CENTER);
        
        // Add panels to top split pane
        topSplitPane.setLeftComponent(jsonPanel);
        topSplitPane.setRightComponent(schemaPanel);
        topSplitPane.setResizeWeight(0.5);
        
        // Result panel
        JPanel resultPanel = new JPanel(new BorderLayout());
        resultPanel.setBorder(BorderFactory.createTitledBorder("Validation Result"));
        
        JTextArea validationResultArea = new JTextArea();
        validationResultArea.setEditable(false);
        validationResultArea.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 14));
        JScrollPane resultScrollPane = new JScrollPane(validationResultArea);
        resultPanel.add(resultScrollPane, BorderLayout.CENTER);
        
        // Buttons panel
        JPanel buttonsPanel = new JPanel();
        
        JButton validateButton = new JButton("Validate Against Schema");
        validateButton.addActionListener(e -> {
            try {
                String jsonInput = schemaValidationJsonArea.getText().trim();
                String schemaInput = schemaInputArea.getText().trim();
                
                if (jsonInput.isEmpty() || schemaInput.isEmpty()) {
                    JOptionPane.showMessageDialog(this, "Both JSON and Schema must be provided.", "Empty Input", JOptionPane.WARNING_MESSAGE);
                    return;
                }
                
                JsonProcessor.ValidationResult jsonValidation = JsonProcessor.validateJson(jsonInput);
                if (!jsonValidation.isValid()) {
                    JOptionPane.showMessageDialog(this, "Invalid JSON input: " + jsonValidation.getMessage(), "Validation Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                
                JsonProcessor.ValidationResult schemaValidation = JsonProcessor.validateJson(schemaInput);
                if (!schemaValidation.isValid()) {
                    JOptionPane.showMessageDialog(this, "Invalid Schema input: " + schemaValidation.getMessage(), "Validation Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                
                JsonProcessor.ValidationResult result = JsonProcessor.validateJsonAgainstSchema(jsonInput, schemaInput);
                validationResultArea.setText(result.getMessage());
                
                if (result.isValid()) {
                    validationResultArea.setForeground(new Color(0, 128, 0)); // Green for success
                    statusLabel.setText("Validation successful");
                } else {
                    validationResultArea.setForeground(Color.RED); // Red for errors
                    statusLabel.setText("Validation failed");
                }
            } catch (Exception ex) {
                validationResultArea.setText("Error during validation: " + ex.getMessage());
                validationResultArea.setForeground(Color.RED);
                statusLabel.setText("Error during validation");
            }
        });
        
        JButton clearButton = new JButton("Clear All");
        clearButton.addActionListener(e -> {
            schemaValidationJsonArea.setText("");
            schemaInputArea.setText("");
            validationResultArea.setText("");
            validationResultArea.setForeground(Color.BLACK);
            statusLabel.setText("Cleared");
        });
        
        buttonsPanel.add(validateButton);
        buttonsPanel.add(clearButton);
        
        // Arrange components in the panel
        JSplitPane mainSplitPane = new JSplitPane(JSplitPane.VERTICAL_SPLIT, topSplitPane, resultPanel);
        mainSplitPane.setDividerLocation(400);
        mainSplitPane.setResizeWeight(0.7);
        
        panel.add(mainSplitPane, BorderLayout.CENTER);
        panel.add(buttonsPanel, BorderLayout.SOUTH);
        
        return panel;
    }
    
    /**
     * Action handler for validating JSON
     */
    private void validateJson(ActionEvent e) {
        try {
            String jsonInput = jsonInputArea.getText().trim();
            if (jsonInput.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please enter JSON data.", "Empty Input", JOptionPane.WARNING_MESSAGE);
                return;
            }
            
            JsonProcessor.ValidationResult result = JsonProcessor.validateJson(jsonInput);
            outputArea.setText(result.getMessage());
            
            if (result.isValid()) {
                outputArea.setForeground(new Color(0, 128, 0)); // Green for success
                statusLabel.setText("JSON is valid");
            } else {
                outputArea.setForeground(Color.RED); // Red for errors
                statusLabel.setText("JSON is invalid");
            }
        } catch (Exception ex) {
            outputArea.setText("Error during validation: " + ex.getMessage());
            outputArea.setForeground(Color.RED);
            statusLabel.setText("Error during validation");
        }
    }
    
    /**
     * Action handler for formatting JSON
     */
    private void formatJson(ActionEvent e) {
        try {
            String jsonInput = jsonInputArea.getText().trim();
            if (jsonInput.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please enter JSON data.", "Empty Input", JOptionPane.WARNING_MESSAGE);
                return;
            }
            
            String formattedJson = JsonProcessor.formatJson(jsonInput);
            jsonInputArea.setText(formattedJson);
            statusLabel.setText("JSON formatted");
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error formatting JSON: " + ex.getMessage(), "Formatting Error", JOptionPane.ERROR_MESSAGE);
            statusLabel.setText("Error formatting JSON");
        }
    }
    
    /**
     * Inserts sample JSON into the input area
     */
    private void insertSampleJson() {
        String sampleJson = "{\n" +
                "  \"id\": 1,\n" +
                "  \"name\": \"John Doe\",\n" +
                "  \"email\": \"john.doe@example.com\",\n" +
                "  \"active\": true,\n" +
                "  \"age\": 30,\n" +
                "  \"scores\": [85, 90, 78],\n" +
                "  \"address\": {\n" +
                "    \"street\": \"123 Main St\",\n" +
                "    \"city\": \"Anytown\",\n" +
                "    \"zipCode\": \"12345\"\n" +
                "  }\n" +
                "}";
        
        jsonInputArea.setText(sampleJson);
        statusLabel.setText("Sample JSON inserted");
    }
} 
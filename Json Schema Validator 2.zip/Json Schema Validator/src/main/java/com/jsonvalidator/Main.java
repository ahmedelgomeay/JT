package com.jsonvalidator;

/**
 * Main class for the JSON Schema Validator application.
 */
public class Main {
    public static void main(String[] args) {
        // Create and display the main application frame
        JsonSchemaValidatorUI mainApp = new JsonSchemaValidatorUI();
        mainApp.setVisible(true);
    }
} 
package com.jsonvalidator;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.github.victools.jsonschema.generator.*;
import org.everit.json.schema.Schema;
import org.everit.json.schema.ValidationException;
import org.everit.json.schema.loader.SchemaLoader;
import org.json.JSONException;
import org.json.JSONObject;
import org.json.JSONTokener;

/**
 * Utility class for JSON validation and schema generation
 */
public class JsonProcessor {
    private static final ObjectMapper objectMapper = new ObjectMapper();

    /**
     * Validates if the provided JSON string is syntactically valid
     *
     * @param jsonContent JSON content to validate
     * @return ValidationResult with success/error information
     */
    public static ValidationResult validateJson(String jsonContent) {
        try {
            // Try to parse the JSON to validate its syntax
            objectMapper.readTree(jsonContent);
            return new ValidationResult(true, "JSON is valid.");
        } catch (JsonProcessingException e) {
            return new ValidationResult(false, "Invalid JSON: " + e.getMessage());
        }
    }

    /**
     * Validates JSON against a provided schema
     *
     * @param jsonContent JSON content to validate
     * @param jsonSchema  JSON schema to validate against
     * @return ValidationResult with success/error information
     */
    public static ValidationResult validateJsonAgainstSchema(String jsonContent, String jsonSchema) {
        try {
            // Parse the schema
            JSONObject rawSchema = new JSONObject(new JSONTokener(jsonSchema));
            Schema schema = SchemaLoader.load(rawSchema);

            // Validate
            schema.validate(new JSONObject(jsonContent));
            return new ValidationResult(true, "JSON is valid against the provided schema.");
        } catch (JSONException e) {
            return new ValidationResult(false, "Error parsing JSON: " + e.getMessage());
        } catch (ValidationException e) {
            StringBuilder errorMessage = new StringBuilder("JSON does not conform to schema:\n");
            e.getAllMessages().forEach(message -> errorMessage.append("- ").append(message).append("\n"));
            return new ValidationResult(false, errorMessage.toString());
        }
    }

    /**
     * Generates a JSON schema from the provided JSON content
     *
     * @param jsonContent JSON content to generate schema from
     * @return Generated JSON schema as a string, or error message
     */
    public static String generateJsonSchema(String jsonContent) {
        try {
            // Parse JSON to determine its structure
            JsonNode jsonNode = objectMapper.readTree(jsonContent);

            // Configure the schema generator
            SchemaGeneratorConfigBuilder configBuilder = new SchemaGeneratorConfigBuilder(
                    SchemaVersion.DRAFT_2019_09,
                    OptionPreset.PLAIN_JSON
            );
            
            SchemaGeneratorConfig config = configBuilder.build();
            SchemaGenerator generator = new SchemaGenerator(config);
            
            // Create a schema representation for the type
            JsonNode schemaNode;
            
            if (jsonNode.isObject()) {
                // For objects, we generate a proper schema
                schemaNode = generator.generateSchema(ObjectNode.class);
                
                // Enrich with properties based on the actual JSON
                enrichSchemaWithProperties(schemaNode, jsonNode);
            } else {
                // For arrays or primitive types
                schemaNode = generator.generateSchema(jsonNode.getClass());
            }

            // Format the schema as a pretty-printed JSON string
            return objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(schemaNode);
        } catch (Exception e) {
            return "Error generating schema: " + e.getMessage();
        }
    }
    
    /**
     * Enriches a schema with properties from a JSON object
     *
     * @param schemaNode Schema node to enrich
     * @param jsonNode   JSON node to extract properties from
     */
    private static void enrichSchemaWithProperties(JsonNode schemaNode, JsonNode jsonNode) {
        if (schemaNode.isObject() && jsonNode.isObject()) {
            ObjectNode schemaObjNode = (ObjectNode) schemaNode;
            
            if (!schemaObjNode.has("properties")) {
                schemaObjNode.set("properties", objectMapper.createObjectNode());
            }
            
            ObjectNode propertiesNode = (ObjectNode) schemaObjNode.get("properties");
            
            // Add properties based on the JSON object
            jsonNode.fieldNames().forEachRemaining(fieldName -> {
                JsonNode fieldValue = jsonNode.get(fieldName);
                ObjectNode propertySchema = objectMapper.createObjectNode();
                
                if (fieldValue.isTextual()) {
                    propertySchema.put("type", "string");
                } else if (fieldValue.isNumber()) {
                    if (fieldValue.isInt() || fieldValue.isLong()) {
                        propertySchema.put("type", "integer");
                    } else {
                        propertySchema.put("type", "number");
                    }
                } else if (fieldValue.isBoolean()) {
                    propertySchema.put("type", "boolean");
                } else if (fieldValue.isArray()) {
                    propertySchema.put("type", "array");
                    // We could add items schema here if needed
                } else if (fieldValue.isObject()) {
                    propertySchema.put("type", "object");
                    enrichSchemaWithProperties(propertySchema, fieldValue);
                } else if (fieldValue.isNull()) {
                    propertySchema.put("type", "null");
                }
                
                propertiesNode.set(fieldName, propertySchema);
            });
            
            // Add required fields (we're making all fields required for now)
            if (jsonNode.size() > 0) {
                ArrayNode requiredArray = objectMapper.createArrayNode();
                jsonNode.fieldNames().forEachRemaining(requiredArray::add);
                schemaObjNode.set("required", requiredArray);
            }
        }
    }

    /**
     * Formats a JSON string to be pretty-printed
     *
     * @param jsonContent JSON content to format
     * @return Formatted JSON string or error message
     */
    public static String formatJson(String jsonContent) {
        try {
            Object json = objectMapper.readValue(jsonContent, Object.class);
            return objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(json);
        } catch (JsonProcessingException e) {
            return "Error formatting JSON: " + e.getMessage();
        }
    }

    /**
     * Result class for validation operations
     */
    public static class ValidationResult {
        private final boolean valid;
        private final String message;

        public ValidationResult(boolean valid, String message) {
            this.valid = valid;
            this.message = message;
        }

        public boolean isValid() {
            return valid;
        }

        public String getMessage() {
            return message;
        }
    }
} 
export const MESSAGES = {
    NO_SEARCH_TERM: "Please enter a search term.",
    NO_RESULTS: "No matching results found.",
    COPY_SUCCESS: "Copied to clipboard!",
    COPY_FAILURE: "Failed to copy!",
    EMAIL_COPIED: "Email copied to clipboard!",
    PASSWORD_COPIED: "Password copied to clipboard!",
    MSISDN_COPIED: "MSISDN copied to clipboard!"
}; 
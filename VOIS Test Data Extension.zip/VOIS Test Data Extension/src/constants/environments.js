export const ENVIRONMENTS = {
    DEV: 'Dev',
    TESTING: 'Testing',
    STAGING: 'Staging',
    PRODUCTION: 'Production'
};
import ToastManager from '../../../utils/ToastManager.js';
import Utils from '../../../utils/Utils.js';

export default class LocalStorageManager {
    constructor() {
        this.clearLocalStorageBtn = document.getElementById('clearLocalStorageBtn');
    }

    init() {
        this.setupEventListeners();
    }

    setupEventListeners() {
        this.clearLocalStorageBtn.addEventListener('click', () => {
            this.clearLocalStorage();
        });
    }

    async clearLocalStorage() {
        try {
            const [activeTab] = await chrome.tabs.query({ active: true, currentWindow: true });
            
            const result = await chrome.scripting.executeScript({
                target: { tabId: activeTab.id },
                func: () => {
                    const itemCount = localStorage.length;
                    localStorage.clear();
                    return itemCount;
                }
            });

            const itemsCleared = result[0]?.result || 0;

            if (itemsCleared === 0) {
                ToastManager.showToast('No local storage items to clear.', ToastManager.FAILURE_TOAST);
                return;
            }

            ToastManager.showToast(
                `${itemsCleared} local storage item(s) cleared.`,
                ToastManager.SUCCESS_TOAST
            );

            // Refresh the page after clearing local storage
            await Utils.refreshActiveTab();

        } catch (error) {
            console.error('Error clearing local storage:', error);
            ToastManager.showToast(
                'Failed to clear local storage. Please try again.',
                ToastManager.FAILURE_TOAST
            );
        }
    }
}
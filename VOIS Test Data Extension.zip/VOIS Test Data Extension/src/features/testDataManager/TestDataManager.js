import testData from "../../data/testData.js";
import ToastManager from "../../utils/ToastManager.js";
import { ENVIRONMENTS} from '../../constants/environments.js';
import { CSS_CLASSES } from '../../constants/cssClasses.js';
import { MESSAGES } from '../../constants/messages.js';
import DarkMode from '../utilityButtons/darkMode/DarkMode.js';
import CookiesManager from '../utilityButtons/cookiesManager/CookiesManager.js';
import LocalStorageManager from '../utilityButtons/localStorageManager/LocalStorageManager.js';

// Storage Keys for persistent data
const STORAGE_KEYS = {
    LAST_SEARCH_QUERY: 'lastSearchQuery',
    LAST_SEARCH_RESULTS: 'lastSearchResults',
    SELECTED_ENVIRONMENT: 'selectedEnvironment'
};

/**
 * TestDataManager class handles the management and display of test data
 * including search, display, and user impersonation functionality
 */
class TestDataManager {
    /**
     * Initialize the TestDataManager with required DOM elements
     * @param {string} searchBoxId - ID of the search input element
     * @param {string} searchBtnId - ID of the search button
     * @param {string} clearBtnId - ID of the clear button
     * @param {string} resultsContainerId - ID of the results container
     */
    constructor(searchBoxId, searchBtnId, clearBtnId, resultsContainerId) {
        // Initialize DOM elements
        this.searchBox = document.getElementById(searchBoxId);
        this.searchBtn = document.getElementById(searchBtnId);
        this.clearBtn = document.getElementById(clearBtnId);
        this.resultsContainer = document.getElementById(resultsContainerId);
        this.environmentSelect = null;
        this.userUid = null;
        
        // Initialize state
        this.currentEnvironment = null;
        this.results = [];
        this.searchTimeout = null;

        // Bind methods that need 'this' context
        this.debouncedSearch = this.debounce(this.performSearch.bind(this), 250);
    }

    /**
     * Initialize the TestDataManager functionality
     */
    init() {
        this.initializeEnvironmentSelect();
        this.loadSavedState();
        this.detectCurrentEnvironment();
        this.setupEventListeners();
    }

    // Environment Management Methods
    
    /**
     * Initialize the environment selection dropdown
     */
    initializeEnvironmentSelect() {
        this.environmentSelect = document.getElementById('environmentSelect');
    }

    /**
     * Handle environment change event
     * @param {string} newEnvironment - The newly selected environment
     */
    handleEnvironmentChange(newEnvironment) {
        this.currentEnvironment = newEnvironment;
        this.updateEnvironmentClass(newEnvironment);
        this.performSearchIfNeeded();
    }

    /**
     * Update the CSS class for the environment select based on selection
     * @param {string} environment - The current environment
     */
    updateEnvironmentClass(environment) {
        this.environmentSelect.classList.remove(
            CSS_CLASSES.DEV_SELECTED, 
            CSS_CLASSES.TESTING_SELECTED, 
            CSS_CLASSES.STAGING_SELECTED,
            CSS_CLASSES.PRODUCTION_SELECTED
        );
        this.environmentSelect.classList.add(`${environment.toLowerCase()}-selected`);
    }

    /**
     * Set default environment (DEV)
     */
    async detectCurrentEnvironment() {
        try {
            // Set default environment to DEV
            this.currentEnvironment = ENVIRONMENTS.DEV;
            this.updateEnvironmentClass(this.currentEnvironment);
            this.environmentSelect.value = this.currentEnvironment;
            this.performSearchIfNeeded();
        } catch (error) {
            console.error('Error setting default environment:', error);
        }
    }

    // Event Listeners Setup

    /**
     * Set up all event listeners
     */
    setupEventListeners() {
        this.setupSearchListeners();
        this.setupEnvironmentListener();
    }

    /**
     * Set up search-related event listeners
     */
    setupSearchListeners() {
        this.searchBox.addEventListener("input", () => {
            const query = this.searchBox.value.trim();
            query === '' ? this.clearSearch() : this.debouncedSearch();
        });

        this.searchBtn.addEventListener("click", () => this.performSearch());
        this.clearBtn.addEventListener("click", () => this.clearSearch());
        
        this.searchBox.addEventListener("keydown", (e) => {
            if (e.key === "Enter") {
                clearTimeout(this.searchTimeout);
                this.performSearch();
            }
        });
    }

    /**
     * Set up environment selection event listener
     */
    setupEnvironmentListener() {
        this.environmentSelect.addEventListener("change", (e) => {
            this.handleEnvironmentChange(e.target.value);
        });
    }

    // Search Functionality

    /**
     * Debounce function to limit the rate of search execution
     * @param {Function} func - Function to debounce
     * @param {number} delay - Delay in milliseconds
     * @returns {Function} - Debounced function
     */
    debounce(func, delay) {
        return (...args) => {
            clearTimeout(this.searchTimeout);
            this.searchTimeout = setTimeout(() => func.apply(this, args), delay);
        };
    }

    /**
     * Perform search based on input query
     */
    performSearch() {
        const query = this.searchBox.value.trim();
        const selectedEnvironment = this.environmentSelect.value;
        this.resultsContainer.innerHTML = "";

        if (!query) {
            this.displayErrorMessage(MESSAGES.NO_SEARCH_TERM);
            return;
        }

        this.results = this.searchTestData(query.toLowerCase(), selectedEnvironment);
        
        if (this.results.length === 0) {
            this.displayErrorMessage(MESSAGES.NO_RESULTS);
            return;
        }

        this.displayResults();
        this.saveState(query);
    }

    /**
     * Search test data based on query and environment
     */
    searchTestData(query, environment) {
        try {
            // Check if test data exists for the environment
            if (!testData || !testData[environment]) {
                console.error(`No test data found for environment: ${environment}`);
                return [];
            }

            // Convert the object of users into an array
            return Object.values(testData[environment]).filter(item => {
                // Ensure all required fields exist
                if (!item.name || !item.email) {
                    return false;
                }

                // Convert all fields to lowercase for case-insensitive search
                const name = item.name.toLowerCase();
                const email = item.email.toLowerCase();
                
                // Use MSISDN field directly, without fallbacks
                const msisdn = item.msisdn ? item.msisdn.toLowerCase() : '';

                // Check if any field contains the search query
                return name.includes(query) || 
                       email.includes(query) || 
                       msisdn.includes(query);
            });
        } catch (error) {
            console.error('Error searching test data:', error);
            return [];
        }
    }

    /**
     * Check if search needs to be performed after environment change
     */
    performSearchIfNeeded() {
        const query = this.searchBox.value.trim();
        if (query) {
            this.performSearch();
        }
    }

    /**
     * Display search results in the UI
     */
    displayResults() {
        this.results.forEach(item => {
            const resultElement = this.createResultItem(item);
            this.resultsContainer.appendChild(resultElement);
        });
    }

    // Result Item Creation Methods

    /**
     * Create a result item element
     * @param {Object} item - Test data item
     * @returns {HTMLElement} - Result item element
     */
    createResultItem(item) {
        const resultDiv = document.createElement("div");
        resultDiv.classList.add(CSS_CLASSES.RESULT_ITEM);
        
        const elements = this.createResultElements(item);
        resultDiv.append(...elements);
        
        return resultDiv;
    }

    /**
     * Create all elements for a result item
     * @param {Object} item - Test data item
     * @returns {Array<HTMLElement>} - Array of elements
     */
    createResultElements(item) {
        return [
            this.createInfoElement("Name:", item.name, null, item),
            this.createInfoElement("MSISDN:", item.msisdn, 
                () => this.copyToClipboard(item.msisdn, MESSAGES.MSISDN_COPIED), 
                item
            ),
            this.createInfoElement("Email:", item.email, 
                () => this.copyToClipboard(item.email, MESSAGES.EMAIL_COPIED), 
                item
            ),
            this.createPasswordElement(item.password)
        ];
    }

    /**
     * Create an info element with label and value
     * @param {string} label - Label text
     * @param {string} value - Value text
     * @param {Function} onCopy - Copy callback function
     * @param {Object} item - Test data item
     * @returns {HTMLElement} - Info element
     */
    createInfoElement(label, value, onCopy, item) {
        const infoP = document.createElement("p");
        const labelElement = this.createStrongElement(label);
        const valueElement = this.createValueElement(label, value);

        infoP.appendChild(labelElement);
        infoP.appendChild(valueElement);

        if (onCopy) {
            const copyButton = this.createCopyButton(onCopy);
            infoP.appendChild(copyButton);
        }

        return infoP;
    }

    createValueElement(label, value) {
        const valueElement = document.createElement("span");
        
        if (label === "Name:") {
            this.formatNameValue(valueElement, value);
        } else if (label === "Email:") {
            this.formatEmailValue(valueElement, value);
        } else {
            valueElement.textContent = value;
        }

        return valueElement;
    }

    formatEmailValue(element, email) {
        const [localPart, domain] = email.split('@');
        
        // Create container for email and tooltip
        const container = document.createElement("div");
        container.classList.add("email-container");
        
        // Create email text element
        const emailText = document.createElement("span");
        if (localPart.length > 8) {
            const truncatedEmail = `${localPart.substring(0, 8)}..@${domain}`;
            emailText.textContent = truncatedEmail;
        } else {
            emailText.textContent = email;
        }
        
        // Create tooltip
        const tooltip = document.createElement("span");
        tooltip.classList.add("email-tooltip");
        tooltip.textContent = email;
        
        // Assemble the elements
        container.appendChild(emailText);
        container.appendChild(tooltip);
        element.appendChild(container);

        // Position tooltip on hover
        container.addEventListener("mouseenter", () => {
            const rect = container.getBoundingClientRect();
            tooltip.style.left = "50%";
            tooltip.style.bottom = "100%";
            tooltip.style.transform = "translateX(-50%)";
            tooltip.style.marginBottom = "10px"; // Adjusted for arrow space
        });
    }

    formatNameValue(element, name) {
        const words = name.split(' ');
        if (words.length > 3) {
            const firstLine = words.slice(0, 3).join(' ');
            const secondLine = words.slice(3).join(' ');
            element.innerHTML = `${firstLine}<br>${secondLine}`;
        } else {
            element.textContent = name;
        }
    }

    // State Management Methods

    /**
     * Save the current search state
     */
    saveState(query) {
        const stateData = {
            [STORAGE_KEYS.LAST_SEARCH_QUERY]: query,
            [STORAGE_KEYS.LAST_SEARCH_RESULTS]: this.results,
            [STORAGE_KEYS.SELECTED_ENVIRONMENT]: this.currentEnvironment
        };

        chrome.storage.local.set(stateData, () => {
            if (chrome.runtime.lastError) {
                console.error('Error saving state:', chrome.runtime.lastError);
            }
        });
    }

    /**
     * Clear the search and reset the state
     */
    clearSearch() {
        this.searchBox.value = "";
        this.resultsContainer.innerHTML = "";
        this.results = [];
        
        const keysToRemove = [
            STORAGE_KEYS.LAST_SEARCH_QUERY,
            STORAGE_KEYS.LAST_SEARCH_RESULTS,
            STORAGE_KEYS.SELECTED_ENVIRONMENT
        ];

        chrome.storage.local.remove(keysToRemove, () => {
            if (chrome.runtime.lastError) {
                console.error('Error clearing state:', chrome.runtime.lastError);
            }
        });
    }

    /**
     * Load the saved search state
     */
    loadSavedState() {
        const keysToGet = [
            STORAGE_KEYS.LAST_SEARCH_QUERY,
            STORAGE_KEYS.LAST_SEARCH_RESULTS,
            STORAGE_KEYS.SELECTED_ENVIRONMENT
        ];

        chrome.storage.local.get(keysToGet, (data) => {
            if (chrome.runtime.lastError) {
                console.error('Error loading state:', chrome.runtime.lastError);
                return;
            }

            if (data[STORAGE_KEYS.SELECTED_ENVIRONMENT]) {
                this.restoreEnvironment(data[STORAGE_KEYS.SELECTED_ENVIRONMENT]);
            }
            
            if (data[STORAGE_KEYS.LAST_SEARCH_QUERY]) {
                this.restoreSearch(data);
            }
        });
    }

    /**
     * Restore the environment from saved state
     */
    restoreEnvironment(savedEnvironment) {
        this.currentEnvironment = savedEnvironment;
        this.environmentSelect.value = savedEnvironment;
        this.updateEnvironmentClass(savedEnvironment);
    }

    /**
     * Restore the search from saved state
     */
    restoreSearch(data) {
        this.searchBox.value = data[STORAGE_KEYS.LAST_SEARCH_QUERY];
        this.results = data[STORAGE_KEYS.LAST_SEARCH_RESULTS] || [];
        
        if (this.results.length > 0) {
            this.displayResults();
        } else {
            this.resultsContainer.textContent = MESSAGES.NO_RESULTS;
        }
    }

    // Utility Methods

    /**
     * Copy text to clipboard
     * @param {string} text - Text to copy
     * @param {string} message - Success message
     */
    async copyToClipboard(text, message = MESSAGES.COPY_SUCCESS) {
        try {
            await navigator.clipboard.writeText(text);
            ToastManager.showToast(message, ToastManager.SUCCESS_TOAST);
        } catch (err) {
            console.error("Failed to copy:", err);
            ToastManager.showToast(MESSAGES.COPY_FAILURE, ToastManager.FAILURE_TOAST);
        }
    }

    // Create a DOM element for a password field
    createPasswordElement(password) {
        const passwordP = document.createElement("p");
        const elements = this.createPasswordElements(password);
        passwordP.append(...elements);
        return passwordP;
    }

    createPasswordElements(password) {
        const labelElement = this.createStrongElement("Password:");
        const passwordContainer = this.createPasswordContainer(password);
        const copyButton = this.createCopyButton(
            () => this.copyToClipboard(password, MESSAGES.PASSWORD_COPIED)
        );
        return [labelElement, passwordContainer, copyButton];
    }

    createPasswordContainer(password) {
        const container = document.createElement("div");
        container.classList.add(CSS_CLASSES.PASSWORD_CONTAINER);

        const hiddenPassword = this.createPasswordSpan(CSS_CLASSES.PASSWORD, "*****");
        const revealedPassword = this.createPasswordSpan(CSS_CLASSES.PASSWORD_REVEALED, password);

        container.append(hiddenPassword, revealedPassword);
        return container;
    }

    createPasswordSpan(className, text) {
        const span = document.createElement("span");
        span.classList.add(className);
        span.textContent = text;
        return span;
    }

    createStrongElement(text) {
        const strong = document.createElement("strong");
        strong.textContent = text;
        return strong;
    }

    // Create a copy button
    createCopyButton(onClick) {
        const button = this.createCopyButtonElement();
        const parentContainer = document.querySelector('#results');
        const tooltip = this.createCopyButtonTooltipElement();

        this.appendElements(parentContainer, button, tooltip);
        this.setupCopyButtonTooltipEventListeners(button, tooltip);
        this.setupCopyButtonEventListener(button, onClick);

        return button;
    }

    createCopyButtonElement() {
        const button = document.createElement("button");
        button.classList.add(CSS_CLASSES.COPY_BTN);
        
        const icon = document.createElement("i");
        icon.classList.add("fas", "fa-copy");
        button.appendChild(icon);
        
        return button;
    }

    createCopyButtonTooltipElement() {
        const tooltip = document.createElement("span");
        tooltip.classList.add("copy-tooltip");
        tooltip.textContent = "Copy to Clipboard";
        return tooltip;
    }

    appendElements(parentContainer, button, tooltip) {
        parentContainer.appendChild(button);
        parentContainer.appendChild(tooltip);
    }

    setupCopyButtonTooltipEventListeners(button, tooltip) {
        button.addEventListener("mouseenter", () => {
            this.showCopyButtonTooltip(button, tooltip);
        });

        button.addEventListener("mouseleave", () => {
            this.hideCopyButtonTooltip(tooltip);
        });
    }

    showCopyButtonTooltip(button, tooltip) {
        tooltip.style.visibility = 'visible';
        tooltip.style.opacity = '1';
        
        const rect = button.getBoundingClientRect();
        tooltip.style.top = `${rect.bottom + window.scrollY + 8}px`;
        tooltip.style.left = `${rect.left + rect.width / 2}px`;
        tooltip.style.transform = 'translateX(-50%)';
    }

    hideCopyButtonTooltip(tooltip) {
        tooltip.style.visibility = 'hidden';
        tooltip.style.opacity = '0';
    }

    setupCopyButtonEventListener(button, onClick) {
        button.addEventListener("click", onClick);
    }

    displayErrorMessage(message) {
        const errorMessageElement = document.createElement("div");
        errorMessageElement.classList.add("error-message");
        errorMessageElement.textContent = message;
        this.resultsContainer.appendChild(errorMessageElement);
    }
}

// Initialize the TestDataManager and DarkMode
// Initialize the TestDataManager, DarkMode, CookiesManager, and LocalStorageManager
const testDataManager = new TestDataManager("searchBox", "searchBtn", "clearBtn", "results");
testDataManager.init();

const darkMode = new DarkMode();
darkMode.init();

const cookiesManager = new CookiesManager();
cookiesManager.init();

const localStorageManager = new LocalStorageManager();
localStorageManager.init();

export default TestDataManager;


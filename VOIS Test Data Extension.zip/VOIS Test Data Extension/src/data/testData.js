const testData = {
    Dev: {
        user1: { 
            name: "Test User 1", 
            email: "TestUser1@test.test", 
            password: "N/A", 
            msisdn: "01111111111",
            testingUserID: "",
            testingV2Uid: "5dd08e02-a9f1-4126-97ad-7575a6afc653"
        },
        user2: {
            name: "Test User 2",
            email: "TestUser1@test.test",
            password: "N/A",
            msisdn: "011111115511",
        },
        user3: {
            name: "Test User 3",
            email: "TestUser2@test.test",
            password: "N/A",
            msisdn: "011111115511",
        }
    },
    Testing: {
        user1: {
            name: "Test User 1",
            email: "TestUser1@test.test",
            password: "N/A",
            msisdn: "01111111111",
        },
        user2: {
            name: "Test User 2",
            email: "TestUser1@test.test",
            password: "N/A",
            msisdn: "011111115511",
        },
        user3: {
            name: "Test User 3",
            email: "TestUser2@test.test",
            password: "N/A",
            msisdn: "011111115511",
        }

    }, // Empty for Testing environment
    Staging: {}, // Empty for Staging environment
    Production: {
        user1: {
            name: "Test User 1",
            email: "TestUser1@test.test",
            password: "N/A",
            msisdn: "01111111111",
        },
        user2: {
            name: "Test User 2",
            email: "TestUser1@test.test",
            password: "N/A",
            msisdn: "011111115511",
        },
        
        
    } // Empty for Production environment
};

export default testData;